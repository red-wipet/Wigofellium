Wigofellium by @mrsuperbuddy8216
--------------------------------
Language: C++
Thanks to: StrychnineRaccoon, GetMbr, pankoza2 and n17pro3426 for testing :)
What's new: Cool effects, fixed MBR owerwriter, cmd appear and a one more time... COMPOSED BYTEBEAT (thanks to StrychnineRaccoon for the idea)
--------------------------------
WARNING:
Running Wigofellium without the .peaceful branch, it will destroy your computer